import java.util.ArrayList;
public class Main {

	static void setPopulation(ArrayList<Animatronique> animatroniques, ArrayList<Piece> pieces) {
		
		for (int i=0;i<animatroniques.size();i++) {
			for (int j=0;j<pieces.size();j++) {
				if (animatroniques.get(i).getNum_position()==pieces.get(j).getId_piece()) {
					pieces.get(j).ajouterAnim(animatroniques.get(i));
					//System.out.println("l'animatronique "+i+" a été ajouter à la piece "+j+".");
					
				}
			}
		}
	}
	
	static void setTime(ArrayList<Animatronique> animatroniques) {
		for (int i=0;i<animatroniques.size();i++) {
			animatroniques.get(i).setTime();
			
		}
	}
	static void chrono(ArrayList<Animatronique> animatroniques) {
		boolean a=true;
		
		do {
			
			Thread thread = new Thread(() -> {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					System.out.println("thread interrompu.");
				}
			});
			
			
			
			if (a) {
				for (int i=0;i<animatroniques.size();i++) {
					if (a) {
					a=animatroniques.get(i).decompte();
					}
				}
			}
			
			
			thread.start();
			try {
				thread.join();
			} catch (InterruptedException e) {
				System.out.println("thread interrompu.");
			}
			
			
			
		} while (a);
	}
	
	
	/*static void chrono(ArrayList<Animatronique> animatroniques) {
		for (int i=0;i<animatroniques.size();i++) {
			animatroniques.get(i).startTime(animatroniques.get(i).getTime());
		}
		boolean a = true;
		while (a) {
			for (int i=0;i<animatroniques.size();i++) {
				if (animatroniques.get(i).getMove()) {
					a = !a;
					System.out.println("l'anim "+i+" doit se déplacer");
				}
			}
		}
	}*/
	
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		ArrayList<Piece> pieces = new ArrayList<>();
		Piece scene = new Piece((int) 0, (int) 3);
		Piece s_a_manger = new Piece((int) 1, (int) 1);
		Piece c_d_pirates_1 = new Piece((int) 2, (int) 1);
		Piece c_d_pirates_2 = new Piece((int) 3, (int) 1);
		Piece c_d_pirates_3 = new Piece((int) 4, (int) 1);
		Piece c_d_pirates_4 = new Piece((int) 5, (int) 1);
		Piece p_entretien = new Piece((int) 6, (int) 1);
		Piece toilette = new Piece((int) 7, (int) 1);
		Piece cuisine = new Piece((int) 8, (int) 1);
		Piece placard = new Piece((int) 9, (int) 1);
		Piece c_gauche = new Piece((int) 10, (int) 1);
		Piece c_c_gauche = new Piece((int) 11, (int) 1);
		Piece c_droit = new Piece((int) 12, (int) 1);
		Piece c_c_droit = new Piece((int) 13, (int) 1);
		Piece p_gauche = new Piece((int) 14, (int) 1);
		Piece p_droit = new Piece((int) 15, (int) 1);
		Piece bureau = new Piece((int) 16, (int) 1);
		
		pieces.add(scene);
		pieces.add(s_a_manger);
		pieces.add(c_d_pirates_1);
		pieces.add(c_d_pirates_2);
		pieces.add(c_d_pirates_3);
		pieces.add(c_d_pirates_4);
		pieces.add(p_entretien);
		pieces.add(toilette);
		pieces.add(cuisine);
		pieces.add(placard);
		pieces.add(c_gauche);
		pieces.add(c_c_gauche);
		pieces.add(c_droit);
		pieces.add(c_c_droit);
		pieces.add(p_gauche);
		pieces.add(p_droit);
		pieces.add(bureau);
		

		
		int[][] chemin = {{0,1,6,10,9,11,14,16},{0,1,7,8,12,13,15,16},{2,3,4,5,10,16},{0,1,7,8,12,13,16}};
		
		ArrayList<Animatronique> animatroniques = new ArrayList<>();
		Animatronique bonnie = new Animatronique((int) 0, chemin[0][0]);
		Animatronique chica = new Animatronique((int) 1, chemin[1][0]);
		Animatronique foxy = new Animatronique((int) 2, chemin[2][0]);
		Animatronique freddy = new Animatronique((int) 3, chemin[3][0]);
		animatroniques.add(bonnie);
		animatroniques.add(chica);
		animatroniques.add(foxy);
		animatroniques.add(freddy);
		
		//for (int i=0;i<animatroniques.size();i++) {
			//System.out.println(animatroniques.get(i).getId_espece()+" - "+animatroniques.get(i).getNum_position());
		//}
		
		setPopulation(animatroniques, pieces);
		setTime(animatroniques);
	
		chrono(animatroniques);
		//move(animatroniques);
	}
	
}

// Scène = 0
// Salle à manger = 1
// Crique des pirates (rideau fermés) = 2
// Crique des pirates (rideau légèrement ouvert) = 3
// Crique des pirates (rideau ouvert) = 4
// Crique des pirates (rideau ouvert (sans Foxy)) = 5
// pièce d'entretien = 6
// Toilette = 7
// cuisine = 8
// placard = 9
// couloir gauche = 10
// coin du couloir gauche = 11
// couloir droit = 12
// coin du couloir droit = 13
// porte gauche = 14
// porte droite = 15
// Bureau = 16

// Num des Animatroniques :
// Bonnie = 0
// Chica = 1
// Foxy = 2
// Freddy = 3