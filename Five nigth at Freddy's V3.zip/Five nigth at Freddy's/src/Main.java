import java.util.ArrayList;


public class Main {

	static void setPopulation(ArrayList<Animatronique> animatroniques, ArrayList<Piece> pieces) {
	// Initialisation des populations des pièces de la liste "pieces"
		
		for (int i=0;i<animatroniques.size();i++) {
			for (int j=0;j<pieces.size();j++) {
			// Parcours les pieces pour chaque animatronique
				if ((animatroniques.get(i).getMove()) && (animatroniques.get(i).getNum_position()==pieces.get(j).getId_piece())) {
				// Si (animatronique doit bouger (initialisé à "true")) && (numéro de position animatronique == id de la pièce)
					pieces.get(j).ajouterAnim(animatroniques.get(i));
					// Ajoute l'animatronique à la pop de la pièce
					System.out.println("l'animatronique "+i+" a été ajouter à la piece "+j+".");
					animatroniques.get(i).setMove(false);
					// Change l'état de mouvement de l'animatronique
				}
			}
		}
	}
	
	static void newPopulation(ArrayList<Animatronique> animatroniques, ArrayList<Piece> pieces, int[][] chemin) {
	// Initialisation des populations des pièces de la liste "pieces"
		
		for (int i=0;i<animatroniques.size();i++) {
			for (int j=0;j<pieces.size();j++) {
			// Parcours les pieces pour chaque animatronique
				if ((animatroniques.get(i).getMove()) && (animatroniques.get(i).getNum_position()==pieces.get(j).getId_piece())) {
				// Si (animatronique doit bouger (initialisé à "true")) && (numéro de position animatronique == id de la pièce)
					pieces.get(j).ajouterAnim(animatroniques.get(i));
					// Ajoute l'animatronique à la pop de la pièce
					if (animatroniques.get(i).getTour()>0) {
					// Après l'initialisation :
						pieces.get(chemin[animatroniques.get(i).getId_espece()][(animatroniques.get(i).getTour())-1]).supprimerAnim(animatroniques.get(i));
					// Supprime l'animatronique de sa précédente pièce
					} else {
						pieces.get(chemin[animatroniques.get(i).getId_espece()][(chemin[animatroniques.get(i).getId_espece()].length)-1]).supprimerAnim(animatroniques.get(i));
					// Supprime l'animatronique de la dernière piece
					}
					System.out.println("l'animatronique "+i+" a été ajouter à la piece "+j+".");
					animatroniques.get(i).setMove(false);
					// Change l'état de mouvement de l'animatronique
				}
			}
		}
	}
	
	static void setTime(ArrayList<Animatronique> animatroniques) {
	// initialise le chrono des animatroniques s'il est à 0 (à 0 au départ)
		do {
			for (int i=0;i<animatroniques.size();i++) {
				if (animatroniques.get(i).getTime()==0) {
					animatroniques.get(i).setTime();
				}
			}
		} while (animatroniques.get(0).getTime()>animatroniques.get(1).getTime() || animatroniques.get(1).getTime()>animatroniques.get(3).getTime());
	}
	
	
	static void chrono(ArrayList<Animatronique> animatroniques) {
	// Gestion des chronos des animatroniques
		boolean a=true;

		do {
			// Initialise un Thread qui attend 1s
			Thread thread = new Thread(() -> {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					System.out.println("thread interrompu.");
				}
			});
			
			
			// Retire 1 au chrono des animatroniques toutes les secondes
			if (a) {
				for (int i=0;i<animatroniques.size();i++) {
					a=animatroniques.get(i).decompte();
					if (!a) {
						break;
					}
				}
			}
			
			
			thread.start();
			try {
				thread.join();
			} catch (InterruptedException e) {
				System.out.println("thread interrompu.");
			}
			
			
			
		} while (a); 
		// Tant que le chrono d'un des animatroniques n'est pas arrivé à 0
	}
	
	static void move(ArrayList<Animatronique> animatroniques, ArrayList<Piece> pieces, int[][] chemin) {
	// Change les animatroniques de numéro de position
		for (int i=0;i<animatroniques.size();i++) {
			
			
			if ((animatroniques.get(i).getMove())   &&   
					(pieces.get(chemin[animatroniques.get(i).getId_espece()][(animatroniques.get(i).getTour())+1]).getPopulation().size()  !=  
					pieces.get(chemin[animatroniques.get(i).getId_espece()][(animatroniques.get(i).getTour())+1]).getPlace_max())) {
			// Si (l'animatronique doit bouger) && (la pièce suivante n'est pas pleine)
				
				animatroniques.get(i).setNum_position(chemin[animatroniques.get(i).getId_espece()][(animatroniques.get(i).getTour())+1]);
				// Change la position de lanimatronique pour la pièce suivante
			} else {
				animatroniques.get(i).setMove(false);
				// Change l'état de mouvement de l'animatronique
			}
			
		}
	}
	

		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
/*----------- INITIALISATION LISTE PIECE ----------------*/
// Piece(id piece, population max)
		
		ArrayList<Piece> pieces = new ArrayList<>();
		Piece scene = new Piece((int) 0, (int) 3);
		Piece s_a_manger = new Piece((int) 1, (int) 1);
		Piece c_d_pirates_1 = new Piece((int) 2, (int) 1);
		Piece c_d_pirates_2 = new Piece((int) 3, (int) 1);
		Piece c_d_pirates_3 = new Piece((int) 4, (int) 1);
		Piece c_d_pirates_4 = new Piece((int) 5, (int) 1);
		Piece p_entretien = new Piece((int) 6, (int) 1);
		Piece toilette = new Piece((int) 7, (int) 1);
		Piece cuisine = new Piece((int) 8, (int) 1);
		Piece placard = new Piece((int) 9, (int) 1);
		Piece c_gauche = new Piece((int) 10, (int) 1);
		Piece c_c_gauche = new Piece((int) 11, (int) 1);
		Piece c_droit = new Piece((int) 12, (int) 1);
		Piece c_c_droit = new Piece((int) 13, (int) 1);
		Piece p_gauche = new Piece((int) 14, (int) 1);
		Piece p_droit = new Piece((int) 15, (int) 1);
		Piece bureau = new Piece((int) 16, (int) 1);
		
		pieces.add(scene);
		pieces.add(s_a_manger);
		pieces.add(c_d_pirates_1);
		pieces.add(c_d_pirates_2);
		pieces.add(c_d_pirates_3);
		pieces.add(c_d_pirates_4);
		pieces.add(p_entretien);
		pieces.add(toilette);
		pieces.add(cuisine);
		pieces.add(placard);
		pieces.add(c_gauche);
		pieces.add(c_c_gauche);
		pieces.add(c_droit);
		pieces.add(c_c_droit);
		pieces.add(p_gauche);
		pieces.add(p_droit);
		pieces.add(bureau);
		
/*------------------- INITIALISATION CHEMIN ANIMATRONIQUE ------------------------
	Cette liste permet de définir le chemin de pièce en pièce des animatronique selon cette logique :
	
	chemin[NUMERO DE L'ANIMATRONIQUE][NUMERO DE LA PIECE]												*/
	
		int[][] chemin = {{0,1,6,10,9,11,14,16},{0,1,7,8,12,13,15,16},{2,3,4,5,10,16},{0,1,7,8,12,13,16}};
		
/*------------------- INITIALISATION LISTE ANIMATRONIQUE ------------------------*/
// Animatronique(id espece, position animatronique)
		
		ArrayList<Animatronique> animatroniques = new ArrayList<>();
		Animatronique bonnie = new Animatronique((int) 0, chemin[0][0]);
		Animatronique chica = new Animatronique((int) 1, chemin[1][0]);
		Animatronique foxy = new Animatronique((int) 2, chemin[2][0]);
		Animatronique freddy = new Animatronique((int) 3, chemin[3][0]);
		animatroniques.add(bonnie);
		animatroniques.add(chica);
		animatroniques.add(foxy);
		animatroniques.add(freddy);

/*---------------------------------------------------------------------------------------------------------------*/	
	
		setPopulation(animatroniques, pieces);
		// Initialise la population des pièces précédement créées
		// (pour une description détaillée, voir ln 6)
	
		while (true) {
		setTime(animatroniques); // Initialisation du chrono des animatroniques (voir ln 29)
		chrono(animatroniques);	 // Gestion des chronos des animatroniques (voir ln 39)
		move(animatroniques, pieces, chemin); // Change les animatroniques de numéro de position (voir ln 78)
		newPopulation(animatroniques, pieces, chemin); // Initialise la nouvelle population des pièces ****A TESTER !!!!!!****
		}
	}
	
}

// Num des pièces :
// Scène = 0
// Salle à manger = 1
// Crique des pirates (rideau fermés) = 2
// Crique des pirates (rideau légèrement ouvert) = 3
// Crique des pirates (rideau ouvert) = 4
// Crique des pirates (rideau ouvert (sans Foxy)) = 5
// pièce d'entretien = 6
// Toilette = 7
// cuisine = 8
// placard = 9
// couloir gauche = 10
// coin du couloir gauche = 11
// couloir droit = 12
// coin du couloir droit = 13
// porte gauche = 14
// porte droite = 15
// Bureau = 16

// Num des Animatroniques :
// Bonnie = 0
// Chica = 1
// Foxy = 2
// Freddy = 3




